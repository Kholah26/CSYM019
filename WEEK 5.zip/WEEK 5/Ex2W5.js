function myClickEvent()
{
  var element =document.getElementById('circle');
  element.style.backgroundColor='blue';
  element.style.opacity=0.5

}
function myLoadFunction(){
  var element =document.getElementById('circle');
  element.addEventListener('click', myClickEvent);


}
document.addEventListener('DOMContentLoaded', myLoadFunction);
